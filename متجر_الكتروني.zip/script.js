// وظيفة بسيطة لتحديث السلة
document.getElementById('checkout').addEventListener('click', function() {
    alert('تم إتمام عملية الشراء بنجاح!');
});

// وظيفة لتسجيل الدخول
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); // منع إعادة تحميل الصفحة
    const email = this[0].value;
    const password = this[1].value;

    // هنا يمكنك إضافة AJAX للتحقق من بيانات المستخدم
    console.log('البريد الإلكتروني:', email);
    console.log('كلمة المرور:', password);
    alert('تسجيل الدخول بنجاح!');
});
